# Visuels presse — AZERTY Global

Ces visuels peuvent être utilisés pour illustrer un article, une brève, une newsletter ou un post éditorial consacré à AZERTY Global.

Crédit conseillé : `AZERTY Global / AMCF`.

## Fichiers

- `Application Microsoft Store.png` - capture de l'application.
- `Carte complète AZERTY Global.png` - carte complète de la disposition.
- `Carte simplifiée AZERTY Global.png` - carte simplifiée de la disposition.
- `L'AZERTY corrigé pas réinventé.png` - visuel éditorial principal.
- `Logo AZERTY Global.png` - logo principal.
- `Logo circulaire AZERTY Global.png` - logo circulaire.
- `Logo AMCF.png` - logo de l'Association pour la Modernisation du Clavier Français.

## Vidéos

Le dossier `Vidéos/` contient de courtes démonstrations au format MP4, utilisables comme sources vidéo pour un article ou une publication sociale :

- `Adresse email.mp4`
- `Exercices AZERTY Global 2.mp4`
- `Langues étrangères.mp4`
- `Programmation.mp4`
- `Typographie française.mp4`
- `Verrouillage Majuscule intelligent.mp4`
