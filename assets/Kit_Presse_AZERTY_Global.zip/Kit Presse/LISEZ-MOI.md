# Kit presse — AZERTY Global

Ce dossier rassemble les éléments utiles aux journalistes pour couvrir la version finale d'AZERTY Global.

Angle principal : corriger l'AZERTY sans changer de clavier, avec une couverture complète du français, de toutes les langues européennes à alphabet latin, grec ou cyrillique, et des principales langues officielles, nationales et régionales d'Afrique francophone écrites en alphabet latin, avec 89 langues auditées.

Note embargo : avant le **lundi 15 juin 2026 à 9 h**, heure de Paris, merci de ne rien publier. Après cette date, ce dossier peut être utilisé comme kit presse public.

## Contenu

- `Communique_Presse_AZERTY_Global.docx` — communiqué de presse.
- `Fiche_Projet_AZERTY_Global.docx` — fiche projet courte.
- `Visuels/` — visuels presse essentiels.

## Liens utiles

- Essayer AZERTY Global en ligne : https://azerty.global
- Télécharger la disposition : https://azerty.global/download
- Page presse : https://azerty.global/presse
- Comparatif : https://azerty.global/comparatif

## Contact presse

Antoine OLIVIER  
Président de l'Association pour la Modernisation du Clavier Français (AMCF)  
Créateur de l'AZERTY Global  
presse@azerty.global

## Visuels

Les visuels fournis peuvent être utilisés pour illustrer un article, une brève, une newsletter ou un post éditorial consacré à AZERTY Global.

Crédit image : `AZERTY Global / Association pour la Modernisation du Clavier Français`.
