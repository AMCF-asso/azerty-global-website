# Press visuals — AZERTY Global

These visuals may be used to illustrate an article, a news brief, a newsletter or an editorial post about AZERTY Global.

Image credit: `AZERTY Global / Association pour la Modernisation du Clavier Français`.

## Files

- `Microsoft Store application.png` - screenshot of the application.
- `Full keyboard map AZERTY Global.png` - complete map of the layout (French key labels).
- `Simplified keyboard map AZERTY Global.png` - simplified map of the layout (French key labels).
- `Editorial visual (French tagline).png` - main editorial visual, with the French tagline « L'AZERTY corrigé, pas réinventé » ("The AZERTY, fixed — not reinvented").
- `Logo AZERTY Global.png` - main logo.
- `Circular logo AZERTY Global.png` - circular logo.
- `Logo AMCF.png` - logo of the Association pour la Modernisation du Clavier Français.

## Videos

The `Videos/` folder contains short MP4 demonstrations, usable as video sources for an article or a social post. The text typed on screen is French — that is the point.

- `Email address.mp4`
- `AZERTY Global demonstration.mp4`
- `Foreign languages.mp4`
- `Programming.mp4`
- `French typography.mp4`
- `Smart Caps Lock.mp4`
