# Press kit — AZERTY Global (English)

This package gathers the material journalists need to cover AZERTY Global, the fixed French keyboard layout, officially released to the public on June 15, 2026.

Main angle: fixing the AZERTY without changing keyboards, with complete coverage of French, of every European language written in the Latin, Greek or Cyrillic alphabet, and of the main official, national and regional languages of French-speaking Africa written in the Latin alphabet — 89 languages audited.

## Contents

- `Press_Release_AZERTY_Global.docx` — press release.
- `Project_Sheet_AZERTY_Global.docx` — short project sheet.
- `Visuals/` — essential press visuals and videos.

## Useful links

- Try AZERTY Global online: https://azerty.global
- Download the layout: https://azerty.global/en/download
- Press page in English: https://azerty.global/en/press
- Layout comparison in English: https://azerty.global/en/comparison

## Press contact

Antoine OLIVIER
President of the Association pour la Modernisation du Clavier Français (AMCF)
Creator of AZERTY Global
presse@azerty.global (English or French)

## Visuals

The visuals provided may be used to illustrate an article, a news brief, a newsletter or an editorial post about AZERTY Global.

Image credit: `AZERTY Global / Association pour la Modernisation du Clavier Français`.
